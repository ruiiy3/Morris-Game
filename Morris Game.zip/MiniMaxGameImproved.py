from Board import *
import sys
import math


class MiniMaxGame:
    def __init__(self):
        self.positionEvaluate = 0
    
    def countPossibleMill(self, board):
        '''
        check empty space, find out how many possible become a new mill

        '''
        count = 0
        for location in range(len(board)):
            if(board[location] == 'x'):
                board[location] = 'W'
                count += self.countMill(location, board)
                board[location] = 'x'
        return count 

    def countBlockMill(self, board):
        '''
        if it's empty, and change to B, find whether it'll be a mill for black
        if true, then means if you put white in here, it can block a mill for black
        '''
        count = 0
        for location in range(len(board)):
            if(board[location] == 'x'):
                board[location] = 'B'
                if closeMill(location, board):
                    count += 1
                board[location] = 'x'
        return count

    def countMill(self,location, board):
        count = 0
        c = board[location]
    
        if location == 0:
            if board[2] == c and board[4] == c : 
                count += 1
            if board[6] == c and board[18] == c:
                count += 1

        elif location == 1:
            if  board[3] == c and board[5] == c:
                count += 1
            if board[11] == c and board[20] == c:
                count += 1

        elif location == 2:
            if board[0] == c and board[4] == c:
                count += 1 
            if board[7] == c and board[15] == c:
                count += 1

        elif location == 3:
            if board[1] == c and board[5] == c:
                count += 1
            if board[10] == c and board[17] == c:
                count += 1

        elif location == 4:
            if board[0] == c and board[2] == c:
                count += 1
            if board[8] == c and board[12] == c:
                count += 1

        elif location == 5:
            if board[1] == c and board[3] == c:
                count += 1
            if board[9] == c and board[14] == c:
                count += 1

        elif location == 6:
            if board[0] == c and board[18] == c:
                count += 1
            if board[7] == c and board[8] == c:
                count += 1

        elif location == 7:
            if board[2] == c and board[15] == c:
                count += 1
            if board[6] == c and board[8] == c:
                count += 1

        elif location == 8:
            if board[4] == c and board[12] == c:
                count += 1
            if board[6] == c and board[7] == c:
                count += 1

        elif location == 9:
            if board[5] == c and board[14] == c:
                count += 1 
            if board[10] == c and board[11] == c:
                count += 1

        elif location == 10:
            if board[3] == c and board[17] == c:
                count += 1
            if board[9] == c and board[11] == c:
               count += 1

        elif location == 11:
            if board[1] == c and board[20] == c:
                count += 1
            if board[9] == c and board[10] == c:
                count += 1

        elif location == 12:
            if board[4] == c and board[8] == c:
                count += 1
            if board[13] == c and board[14] == c:
                count += 1
            if board[15] == c and board[18] == c:
                count += 1

        elif location == 13:
            if board[12] == c and board[14] == c:
                count += 1
            if board[16] == c and board[19] == c:
                count += 1

        elif location == 14:
            if board[5] == c and board[9] == c:
                count += 1
            if board[12] == c and board[13] == c:
                count += 1
            if board[17] == c and board[20] == c:
                count += 1

        elif location == 15:
            if board[2] == c and board[7] == c:
                count += 1
            if board[12] == c and board[18] == c:
                count += 1
            if board[16] == c and board[17] == c:
                count += 1

        elif location == 16:
            if board[13] == c and board[19] == c:
                count += 1
            if board[15] == c and board[17] == c:
                count += 1

        elif location == 17:
            if board[3] == c and board[10] == c:
                count += 1
            if board[14] == c and board[20] == c:
                count += 1
            if board[15] == c and board[16] == c:
                count += 1

        elif location == 18:
            if board[0] == c and board[6] == c:
                count += 1
            if board[12] == c and board[15] == c:
                count += 1
            if board[19] == c and board[20] == c:
                count += 1

        elif location == 19:
            if board[13] == c and board[16] == c:
                count += 1
            if board[18] == c and board[20] == c:
                count += 1

        elif location == 20:
            if board[1] == c and board[11] == c:
                count += 1
            if board[14] == c and board[17] == c:
                count += 1
            if board[18] == c and board[19] == c:
                count += 1
           
        return count
    def staticEstimationMidEndImproved(self, board):
        '''
        static estimation for opening, given by professor
        '''
        numWhitePieces = board.count('W')
        numBlackPieces = board.count('B')
        numPossibleMill = self.countPossibleMill(board)
        numPossibleBlock = self.countBlockMill(board)
        L = GenerateMovesMidgameEndgame(flipBoard(board))
        numBlackMoves = len(L)
        
        if numBlackPieces <= 2: #white win
            return 10000
        elif numWhitePieces <= 2: #black win
            return -10000
        elif numBlackMoves == 0: 
            return 10000
        else:
            return 1000*(numWhitePieces - numBlackPieces + numPossibleMill + numPossibleBlock )  - 5*numBlackMoves  
        #more blackmove you have, worst position you are
    
    def MaxMin(self, board, depth):
        if depth == 0:
            self.positionEvaluate += 1
            static =  self.staticEstimationMidEndImproved(board)
            return static, board
        else:
            v = -math.inf
            L = GenerateMovesMidgameEndgame(board)
            # get child
            for child in L:
                childStatic,_ = self.MinMax(child, depth - 1)
                if v < childStatic:      
                    outBoard = child     
                    v = childStatic
            return v, outBoard

    def MinMax(self, board, depth):
        if depth == 0:
            self.positionEvaluate += 1
            static = self.staticEstimationMidEndImproved(board)
            return  static, board
        else:
            v = math.inf
            L = GenerateMove(flipBoard(board))
            for child in L:
                childStatic,_ = self.MaxMin(flipBoard(child), depth - 1)                   
                if v > childStatic: 
                    outBoard = child     
                    v = childStatic
                    
            return v, outBoard
    

if __name__ == '__main__':
    if len(sys.argv) != 4:
        print("Wrong input! Input Format -> python filename input.txt output.txt depth")
        sys.exit()
    input1 = open(sys.argv[1], 'r').read()
    board = list(input1)
    output = open(sys.argv[2], 'w')
    depth = int(sys.argv[3])
    morris = MiniMaxGame()
    staticV, outputPosition = morris.MaxMin(board, depth)
    output.write(''.join(outputPosition))
    str1 = "Board Position: " + ''.join(outputPosition) 
    str2 = "Positions evaluated by static estimation: "+ str(morris.positionEvaluate) 
    str3 = "MINIMAX estimate: "+ str(staticV)
    print(str1)
    print(str2)
    print(str3)
    result = open("output.txt", 'a')
    result.write("MiniMaxGame Input position: " + input1 + " Output position:" + ''.join(outputPosition) + "\n")
    result.write(str2+ '\n')
    result.write(str3+ '\n')
