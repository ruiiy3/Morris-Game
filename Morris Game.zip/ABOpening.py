from Board import *
import sys
import math


class ABOpening:
    def __init__(self):
        self.positionEvaluate = 0
        

    def staticEstimationOpening(self, board):
        '''
        static estimation for opening, given by professor
        '''
        numWhitePieces = board.count('W')
        numBlackPieces = board.count('B')
        return numWhitePieces - numBlackPieces 
    
    def alphaBetaMaxMin(self, board, depth, alpha, beta):
        if depth == 0:
            static =  self.staticEstimationOpening(board)
            self.positionEvaluate += 1 
            return static, board
        else:
            L = GenerateMovesOpening(board)
            v = -math.inf
            # get child
            for child in L:
                childStatic,_ = self.alphaBetaMinMax(child, depth - 1, alpha, beta)
                if v < childStatic:      
                    outBoard = child
                    v = childStatic                         
                if v >= beta:
                    return v, outBoard
                else:
                    alpha = max(v, alpha)
            
            return v, outBoard

    def alphaBetaMinMax(self, board, depth, alpha, beta):
        if depth == 0:
            self.positionEvaluate += 1
            static = self.staticEstimationOpening(board)
            return  static, board
        else:
            L = GenerateMovesOpening(flipBoard(board))
            v = math.inf  
            for child in L:
                childStatic,_ = self.alphaBetaMaxMin(flipBoard(child), depth - 1, alpha, beta)                   
                if v > childStatic: 
                    outBoard = child     
                    v = childStatic         
                if v <= alpha:
                    return v, outBoard
                else:
                    beta = min(v, beta)
            return v, outBoard
    

if __name__ == '__main__':
    if len(sys.argv) != 4:
        print("Wrong input! Input Format -> python filename input.txt output.txt depth")
        sys.exit()
    input1 = open(sys.argv[1], 'r').read()
    board = list(input1)
    output = open(sys.argv[2], 'w')
    depth = int(sys.argv[3])
    morris = ABOpening()
    staticV, outputPosition = morris.alphaBetaMaxMin(board, depth, -math.inf, math.inf)
    str1 = "Board Position: " + ''.join(outputPosition) 
    str2 = "Positions evaluated by static estimation: "+ str(morris.positionEvaluate) 
    str3 = "MINIMAX estimate: "+ str(staticV)
    print(str1)
    print(str2)
    print(str3)
    result = open("output.txt", 'a')
    result.write("MiniMaxOpening Input position: " + input1 + " Output position:" + ''.join(outputPosition) + "\n")
    result.write(str2+ '\n')
    result.write(str3+ '\n')
