from Board import *
import sys
import math


class MiniMaxOpening:
    def __init__(self):
        self.positionEvaluate = 0
        
    def staticEstimationOpening(self, board):
        '''
        static estimation for opening, given by professor
        '''
        numWhitePieces = board.count('W')
        numBlackPieces = board.count('B')
        return numWhitePieces - numBlackPieces 
    
    def MaxMin(self, board, depth):
        board = list(board)
        if depth == 0:
            self.positionEvaluate += 1
            static =  self.staticEstimationOpening(board)
            return static, board
        else:
            L = GenerateMovesOpening(board)
            v = -math.inf          
            # get child
            for child in L:
                childStatic,_ = self.MinMax(child, depth - 1)            
                if v < childStatic:   
                    outBoard = child   
                    v = childStatic       
            return v, outBoard

    def MinMax(self, board, depth):
        board = list(board)
        if depth == 0:
            self.positionEvaluate += 1
            static = self.staticEstimationOpening(board)
            return  static, board
        else:
            v = math.inf
            #black
            L = GenerateMovesOpening(flipBoard(board))
            for child in L:
                #white
                childStatic,_ = self.MaxMin(flipBoard(child), depth - 1)                   
                if v > childStatic:    
                    outBoard = child  
                    v = childStatic   
            return v, outBoard
    

if __name__ == '__main__':
    if len(sys.argv) != 4:
        print("Wrong input! Input Format -> python filename input.txt output.txt depth")
        sys.exit()
    input1 = open(sys.argv[1], 'r').read()
    output = open(sys.argv[2], 'w')
    depth = int(sys.argv[3])
    morris = MiniMaxOpening()
    staticV, outputPosition = morris.MaxMin(input1, depth)
    output.write(''.join(outputPosition))
    str1 = "Board Position: " + ''.join(outputPosition) 
    str2 = "Positions evaluated by static estimation: "+ str(morris.positionEvaluate) 
    str3 = "MINIMAX estimate: "+ str(staticV)
    print(str1)
    print(str2)
    print(str3)
    result = open("output.txt", 'a')
    result.write("MiniMaxOpening Input position: " + input1 + " Output position:" + ''.join(outputPosition) + "\n")
    result.write(str2+ '\n')
    result.write(str3+ '\n')

