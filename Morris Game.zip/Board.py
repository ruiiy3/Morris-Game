"""
all basic functions will be used in different program
"""


def GenerateMovesOpening(board):
    return GenerateAdd(board)


def GenerateAdd(board):
    """
    In the opening phase, generate moves created by adding a white piece
    one board postion, check all empty place, empty -> white, only one change each time
    after add one white, if it's mill, remove one black
    then add all possible solution to the L list
    """
    L = []
    for location in range(len(board)):
        if board[location] == 'x':
            newBoard = list(board)
            newBoard[location] = 'W'
            if closeMill(location, newBoard):
                L = GenerateRemove(newBoard, L)
            else:
                L.append(newBoard)
    return L


def GenerateMove(board):
    """
    midgame phase
    move a white piece to an adjacent location
    if it's white, check it's neighbor is empty or not, if it's, empty-> W, W-> empty
    Then check if it's mill, if it's remove one black
    add all possible to L list
    """
    L = []
    for location in range(len(board)):
        if board[location] == 'W':
            n = neighbors(location)  # list
            for neighbor in n:
                if board[neighbor] == 'x':
                    newBoard = list(board)
                    newBoard[location] = 'x'
                    newBoard[neighbor] = 'W'
                    if closeMill(neighbor, newBoard):
                        L = GenerateRemove(newBoard, L)
                    else:
                        L.append(newBoard)
    return L


def GenerateHopping(board):
    """
    endgame phase
    loop over last three white pieces
    find empty space, empty-> white, white-> empty, if it's mill, remove black
    add all possible to L
    """
    L = []
    for alpha in range(len(board)):
        if board[alpha] == 'W':
            for beta in range(len(board)):
                if board[beta] == 'x':
                    newBoard = list(board)
                    newBoard[alpha] = 'x'
                    newBoard[beta] = 'W'
                    if closeMill(beta, newBoard):
                        L = GenerateRemove(newBoard, L)
                    else:
                        L.append(newBoard)
    return L


def GenerateMovesMidgameEndgame(board):
    """
    if there are last three pieces, you can move W to any place you want
    else move to an adjacent location
    """
    L = []
    if board.count('W') == 3:
        L = GenerateHopping(board)
    else:
        L = GenerateMove(board)
    return L


def GenerateRemove(board, L):
    """
    Remove a black piece from the board
    will be use in multiple functions like generatemove, generateadd, generatehopping etc
    check all position, if it's B and also not mill, B-> empty, add all possible to L
    if all black pieces are in mills, no position change, then add board to L
    """
    check = True
    for position in range(len(board)):
        if board[position] == 'B':
            if not closeMill(position, board):
                newBoard = list(board)
                newBoard[position] = 'x'
                L.append(newBoard)
                check = False   
    if check:
        L.append(board)
    return L


def closeMill(location, board):
    """
    three pieces equal, then it's mill
    """
    c = board[location]
    if c == 'W' or c == 'B':
        if location == 0:
            if (board[2] == c and board[4] == c) or (board[6] == c and board[18] == c):
                return True
            else:
                return False

        elif location == 1:
            if (board[3] == c and board[5] == c) or (board[11] == c and board[20] == c):
                return True
            else:
                return False

        elif location == 2:
            if (board[0] == c and board[4] == c) or (board[7] == c and board[15] == c):
                return True
            else:
                return False

        elif location == 3:
            if (board[1] == c and board[5] == c) or (board[10] == c and board[17] == c):
                return True
            else:
                return False

        elif location == 4:
            if (board[0] == c and board[2] == c) or (board[8] == c and board[12] == c):
                return True
            else:
                return False

        elif location == 5:
            if (board[1] == c and board[3] == c) or (board[9] == c and board[14] == c):
                return True
            else:
                return False

        elif location == 6:
            if (board[0] == c and board[18] == c) or (board[7] == c and board[8] == c):
                return True
            else:
                return False

        elif location == 7:
            if (board[2] == c and board[15] == c) or (board[6] == c and board[8] == c):
                return True
            else:
                return False

        elif location == 8:
            if (board[4] == c and board[12] == c) or (board[6] == c and board[7] == c):
                return True
            else:
                return False

        elif location == 9:
            if (board[5] == c and board[14] == c) or (board[10] == c and board[11] == c):
                return True
            else:
                return False

        elif location == 10:
            if (board[3] == c and board[17] == c) or (board[9] == c and board[11] == c):
                return True
            else:
                return False

        elif location == 11:
            if (board[1] == c and board[20] == c) or (board[9] == c and board[10] == c):
                return True
            else:
                return False

        elif location == 12:
            if (board[4] == c and board[8] == c) or (board[13] == c and board[14] == c) or (
                    board[15] == c and board[18] == c):
                return True
            else:
                return False

        elif location == 13:
            if (board[12] == c and board[14] == c) or (board[16] == c and board[19] == c):
                return True
            else:
                return False

        elif location == 14:
            if (board[5] == c and board[9] == c) or (board[12] == c and board[13] == c) or (
                    board[17] == c and board[20] == c):
                return True
            else:
                return False

        elif location == 15:
            if (board[2] == c and board[7] == c) or (board[12] == c and board[18] == c) or (
                    board[16] == c and board[17] == c):
                return True
            else:
                return False

        elif location == 16:
            if (board[13] == c and board[19] == c) or (board[15] == c and board[17] == c):
                return True
            else:
                return False

        elif location == 17:
            if (board[3] == c and board[10] == c) or (board[14] == c and board[20] == c) or (
                    board[15] == c and board[16] == c):
                return True
            else:
                return False

        elif location == 18:
            if (board[0] == c and board[6] == c) or (board[12] == c and board[15] == c) or (
                    board[19] == c and board[20] == c):
                return True
            else:
                return False

        elif location == 19:
            if (board[13] == c and board[16] == c) or (board[18] == c and board[20] == c):
                return True
            else:
                return False

        elif location == 20:
            if (board[1] == c and board[11] == c) or (board[14] == c and board[17] == c) or (
                    board[18] == c and board[19] == c):
                return True
            else:
                return False

    return False


def neighbors(location):
    """
    hardcode each pieces' neighbors according to the Morris Game graph given by professor
    """
    if location == 0:
        return [1, 2, 6]
    elif location == 1:
        return [0, 3, 11]
    elif location == 2:
        return [0, 3, 4, 7]
    elif location == 3:
        return [1, 2, 10, 5]
    elif location == 4:
        return [2, 5, 8]
    elif location == 5:
        return [3, 4, 9]
    elif location == 6:
        return [0, 7, 18]
    elif location == 7:
        return [2, 6, 8, 15]
    elif location == 8:
        return [4, 7, 12]
    elif location == 9:
        return [5, 10, 14]
    elif location == 10:
        return [3, 9, 11, 17]
    elif location == 11:
        return [1, 10, 20]
    elif location == 12:
        return [8, 13, 15]
    elif location == 13:
        return [12, 14, 16]
    elif location == 14:
        return [9, 13, 17]
    elif location == 15:
        return [7, 12, 16, 18]
    elif location == 16:
        return [13, 15, 17, 19]
    elif location == 17:
        return [10, 14, 16, 20]
    elif location == 18:
        return [6, 15, 19]
    elif location == 19:
        return [16, 18, 20]
    elif location == 20:
        return [11, 17, 19]
    else:
        return []


def flipBoard(board):
    """
    W to B, B to W
    """
    newBoard = board.copy()
    for location in range(len(newBoard)):
        if newBoard[location] == 'W':
            newBoard[location] = 'B'
        elif newBoard[location] == 'B':
            newBoard[location] = 'W'
    return newBoard
    

